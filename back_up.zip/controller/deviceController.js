// deviceController.js
const Device = require('../model/RegisterDevice');
const servicesModel = require('../model/servicesModel');
const Log = require('../model/logs');
const Joi = require('joi');
// const deviceController = {};

/**
 * api      POST @/devices/register
 * desc     @register for logger access only
 */
const registerNewDevice = async (req, res) => {
  try {
    const schema = Joi.object({
      deviceId: Joi.string().required(),
      status: Joi.string().required(),
      departmentName: Joi.string().required(),
      hospitalName: Joi.string().required(),
      wardNo: Joi.string().required().optional(),
      doctorName: Joi.string().required(),
      bioMed: Joi.string().allow("").optional(),
      IMEI_NO: Joi.string().allow("").optional(),
      ventilatorOperator: Joi.string().allow("").optional(),
      
    })
    let result = schema.validate(req.body);
    if (result.error) {
      return res.status(400).json({
        statusCode: 400,
        statusValue: "Validation Error",
        message: result.error.details[0].message,
      })
    }
    const newDevice = new Device(req.body);
    const savedDevice = await newDevice.save();
    if (savedDevice) {
      return res.status(201).json({
        statusCode: 201,
        statusValue: "SUCCESS",
        message: "Data added successfully."
      })
    }
    return res.status(400).json({
      statusCode: 400,
      statusValue:"FAIL",
      message:"Error! Data not added."
    })
  } catch (err) {
    res.status(500).json({
      statusCode:500,
      statusValue:"FAIL",
      message:"Internal server error",
      data:{
        name:"deviceController/registerNewDevice",
        err:err
      }
    })
  }
}

const getAllDevices = async (req, res) => {
  try {
    const devices = await Device.find().sort({ createdAt: 'desc' });
    if (devices) {
      return res.status(200).json({
        statusCode: 200,
        statusValue: "SUCCESS",
        message: "The device lists has been retrieved successfully.",
        data:devices
      })
    }
  } catch (error) {
    res.status(500).json({
      statusCode:500,
      statusValue:"FAIL",
      message:"Internal server error",
      data:{
        name:"deviceController/getAllDevices",
        err:err
      }
    })
  }
};

const addDeviceService = async (req, res) => {
  try {
    const schema = Joi.object({
      deviceId: Joi.string().required(),
      message: Joi.string().required(),
      date: Joi.string().required(),
      serialNo: Joi.string().required(),
    })
    let result = schema.validate(req.body);
    if (result.error) {
      return res.status(400).json({
        statusCode: 400,
        statusValue: "Validation Error",
        message: result.error.details[0].message,
      })
    }
    const project_code = req.query.project_code
    const newServices = new servicesModel(req.body);
    const savedServices = await newServices.save();
    if (savedServices) {
      return res.status(201).json({
        statusCode: 201,
        statusValue: "SUCCESS",
        message: "Data added successfully."
      })
    }
    return res.status(400).json({
      statusCode: 400,
      statusValue:"FAIL",
      message:"Error! Data not added."
    })
  } catch (err) {
    res.status(500).json({
      statusCode:500,
      statusValue:"FAIL",
      message:"Internal server error",
      data:{
        name:"deviceController/addDeviceService",
        err:err
      }
    })
  }
}
// deviceController.createDevice = async (req, res) => {
  
//   const newDevice = new Device(req.body);
//   try {
//     const savedDevice = await newDevice.save();
//     res.status(201).json(savedDevice);
//   } catch (error) {
//     res.status(400).json({ message: error.message });
//   }
// };



// deviceController.getDeviceById = async (req, res) => {
//   const { deviceId } = req.params;
//   try {
//     const device = await Device.findOne({ DeviceId: deviceId });
//     if (!device) {
//       res.status(404).json({ message: 'Device not found' });
//     } else {
//       res.status(200).json(device);
//     }
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// deviceController.createLogs = async(req,res) =>{
//   const newLog = new Log(req.body);
//   try{
//     const savedLog = await newLog.save();
//     res.status(201).json(savedLog);
//   }catch(error){
//     res.status(400).json({message:error.message});
//   }
// }







// deviceController.updateDevice = async (req, res) => {
//   const { deviceId } = req.params;
//   try {
//     const updatedDevice = await Device.findOneAndUpdate(
//       { DeviceId: deviceId },
//       req.body,
//       { new: true }
//     );
//     if (!updatedDevice) {
//       res.status(404).json({ message: 'Device not found' });
//     } else {
//       res.status(200).json(updatedDevice);
//     }
//   } catch (error) {
//     res.status(400).json({ message: error.message });
//   }
// };

// deviceController.deleteDevice = async (req, res) => {
//   const { deviceId } = req.params;
//   try {
//     const deletedDevice = await Device.findOneAndDelete({ DeviceId: deviceId });
//     if (!deletedDevice) {
//       res.status(404).json({ message: 'Device not found' });
//     } else {
//       res.status(200).json(deletedDevice);
//     }
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

module.exports = {
  registerNewDevice,
  getAllDevices,
  addDeviceService
}
